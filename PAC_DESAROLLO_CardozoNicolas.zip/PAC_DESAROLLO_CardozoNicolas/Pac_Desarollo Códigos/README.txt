EXPLICACION DE PAC DE DESAROLLOR DE LENGUAJES DE MARCAS Y SISTEMAS DE GESTIÓN DE LA INFORMACIÓN


El siguiente proyecto consiste en una página web de compra de entradas para los conciertos de One Direction en su gira por España en 2025. El sitio permite a los usuarios seleccionar una de las fechas disponibles, elegir el número de entradas y la categoría, así como elegir el método de pago. La compra se confirma y se muestran los detalles en una página de confirmación.

ESTRUCTURA DEL PROYECTO


El proyecto está dividido en tres archivos principales:


HTML: La estructura básica de la página web.

CSS: El diseño y estilo visual de la página.

JavaScript: Lógica de interacción y almacenamiento de datos.



ARCHIVOS



index.html: Esta es página principal donde se muestran las fechas de los conciertos, la descripción de la gira y un formulario de compra.

confirmacion.html: Aquí se encuentra la página de confirmación de compra donde el usuario verá los detalles de la compra realizada.

styles.css: Este archivo contiene los estilos y el diseño visual de la página.

script.js: Aquí se encuentra toda la lógica del formulario, validaciones y almacenamiento en sessionStorage.







DESCRIPCIÓN DE PROYECTO


El proyecto que he creado tiene como objetivo proporcionar una experiencia de usuario completa para la compra de entradas. A continuación, explico cada parte en detalle:

HTML - Estructura de la Página
El archivo index.html contiene la estructura básica de la página. Está dividido en varias secciones:



Header: Aquí se muestra el título "One Direction" y una imagen de la banda.

Descripción: Aquí me he encargado de proporcionar información sobre el regreso de One Direction a España, con un texto detallado sobre la gira.

Fechas de Conciertos: Muestra una tabla con las fechas, lugares, horas y precios de los conciertos.

Formulario de Compra: Permite a los usuarios seleccionar la fecha, la cantidad de entradas, la categoría (general o VIP) y el método de pago. También incluye un campo para ingresar el nombre del usuario.

El formulario tiene validación para asegurarse de que todos los campos estén completos antes de enviarlo. Los datos se almacenan en el sessionStorage para ser mostrados posteriormente en la página de confirmación.



CSS - ESTILO VISUAL



El archivo styles.css contiene los estilos para hacer que la página sea visualmente atractiva. Algunas características clave que he incluido son:

Un fondo de color suave y un diseño centrado para una mejor presentación visual.

Botón de confirmación azul que cambia ligeramente de color cuando el usuario pasa el ratón por encima, utilizando la propiedad :hover.

Los estilos elegidos permiten que la página se vea bien en dispositivos móviles, gracias a la propiedad meta de viewport.



JAVASCRIPT - LÓGICA DE INTERACCIÓN

El archivo script.js gestiona la interacción de los usuarios en la página, asegurando que la compra sea procesada correctamente. Aquí nombro sus partes principales:


Validación del Formulario: Antes de enviar los datos, se asegura de que todos los campos estén completos. Si algún campo está vacío, el formulario no se enviará y aparecerá un mensaje de alerta.

Almacenamiento de Datos: Los datos del formulario (nombre, fecha del concierto, cantidad de entradas, categoría y método de pago) se almacenan en sessionStorage, lo que permite que estos datos se mantengan disponibles cuando el usuario navega a la página de confirmación.

Página de Confirmación: En la página confirmacion.html, los datos almacenados en sessionStorage se muestran para que los usuarios pueda ver un resumen de su compra.



Cómo usar el Proyecto
Lo ideal sería clonar o descargar el proyecto en una máquina local.

Abrir el archivo index.html en tu navegador para ver la página de inicio.

Rellenar el formulario con tus datos, seleccionar las entradas y confirmar la compra.

En la página de confirmación, podrás ver los detalles de la compra.