document.getElementById('formCompra').addEventListener('submit', function (event) {
    event.preventDefault();

    const nombre = document.getElementById('nombre').value;
    const fecha = document.getElementById('fecha').value;
    const cantidad = document.getElementById('cantidad').value;
    const categoria = document.getElementById('categoria').value;
    const metodoPago = document.querySelector('input[name="pago"]:checked').value;

    if (!nombre || !fecha || !cantidad || !categoria || !metodoPago) {
        alert("Por favor, complete todos los campos.");
        return;
    }

    sessionStorage.setItem('nombre', nombre);
    sessionStorage.setItem('fecha', fecha);
    sessionStorage.setItem('cantidad', cantidad);
    sessionStorage.setItem('categoria', categoria);
    sessionStorage.setItem('metodoPago', metodoPago);

    window.location.href = "confirmacion.html";
});
